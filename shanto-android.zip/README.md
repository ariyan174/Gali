# Shanto – Gali Guard (Android)

Gali type korle text auto muche jay, phone home-e chole jay, ar calm screen ashe.
Commitment lock: 1 / 5 / 10 / 30 din, 1 bochor ba nijer din.

## GitHub theke APK banano
1. GitHub-e notun repo kholo.
2. Ei folder-er shob file (`.github` folder shoho) repo-te upload koro.
3. Repo-r **Actions** tab -> **Build APK** -> sesh hole **Shanto-APK** artifact download koro.
4. Zip khule `app-debug.apk` phone-e install koro.
5. App kholo -> **Permission dao** -> Accessibility-te **Shanto** on koro -> guard on koro.
