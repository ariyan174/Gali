package com.shanto.guard

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }
    private val dayMap = mapOf(
        R.id.chip1 to 1, R.id.chip5 to 5, R.id.chip10 to 10,
        R.id.chip30 to 30, R.id.chip365 to 365, R.id.chip0 to 0
    )

    private lateinit var sw: SwitchMaterial
    private lateinit var chips: ChipGroup
    private lateinit var custom: EditText
    private lateinit var newWord: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sw = findViewById(R.id.swGuard)
        chips = findViewById(R.id.chips)
        custom = findViewById(R.id.customDays)
        newWord = findViewById(R.id.newWord)

        findViewById<MaterialButton>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        sw.setOnClickListener {
            if (Prefs.isLocked(this)) {
                sw.isChecked = true
                toast("Lock cholche — ekhon off kora jabe na")
            } else {
                Prefs.setOn(this, sw.isChecked)
                Prefs.setEnd(this, 0L)
            }
            refresh()
        }

        findViewById<MaterialButton>(R.id.btnStart).setOnClickListener { startGuard() }

        findViewById<MaterialButton>(R.id.btnAdd).setOnClickListener {
            val w = newWord.text.toString().trim().lowercase()
            if (w.isNotEmpty()) Prefs.addWord(this, w)
            newWord.text.clear(); refresh()
        }
        findViewById<MaterialButton>(R.id.btnDel).setOnClickListener {
            val w = newWord.text.toString().trim().lowercase()
            if (w.isNotEmpty()) Prefs.removeWord(this, w)
            newWord.text.clear(); refresh()
        }
    }

    private fun startGuard() {
        if (Prefs.isLocked(this)) { toast("Lock age theke cholche"); return }
        val days = custom.text.toString().toIntOrNull() ?: dayMap[chips.checkedChipId]
        if (days == null) { toast("Age somoy bechhe nao"); return }
        val apply = {
            Prefs.setOn(this, true)
            Prefs.setEnd(this, if (days > 0) System.currentTimeMillis() + days * 86_400_000L else 0L)
            refresh()
        }
        if (days > 0) {
            AlertDialog.Builder(this)
                .setTitle("Nishchit?")
                .setMessage("$days din guard off korte parbe na.")
                .setPositiveButton("Hya, lock koro") { _, _ -> apply() }
                .setNegativeButton("Na", null)
                .show()
        } else apply()
    }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/") && s.contains("GuardService")
    }

    private fun refresh() {
        findViewById<TextView>(R.id.svcStatus).text =
            if (serviceEnabled()) "Permission on ✓" else "Permission off ✗"
        findViewById<TextView>(R.id.blocked).text = "Aj: ${Prefs.blockedToday(this)} ti block"
        sw.isChecked = Prefs.isOn(this)
        val lockText = findViewById<TextView>(R.id.lockText)
        if (Prefs.isLocked(this)) {
            val ms = Prefs.endAt(this) - System.currentTimeMillis()
            val d = ms / 86_400_000L
            val h = ms % 86_400_000L / 3_600_000L
            val m = ms % 3_600_000L / 60_000L
            val s = ms % 60_000L / 1000L
            lockText.text = "Lock: $d din $h ghonta $m min $s sec baki"
            lockText.visibility = android.view.View.VISIBLE
        } else lockText.visibility = android.view.View.GONE
        val words = Prefs.custom(this)
        findViewById<TextView>(R.id.wordList).text =
            if (words.isEmpty()) "Ekhono nijer kono word nai" else words.joinToString(", ")
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }
}
