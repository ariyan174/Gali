package com.shanto.guard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class GuardService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastHit = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) return
        if (!Prefs.isOn(this)) return
        if (e.packageName == packageName) return
        val src = e.source ?: return
        if (src.isPassword) return

        val text = e.text.joinToString(" ")
        if (text.isBlank() || !Words.hit(this, text)) return

        val now = System.currentTimeMillis()
        if (now - lastHit < 1500) return
        lastHit = now

        // 1) text muche felo
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        }
        src.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

        // 2) chat theke ber kore phone-er home-e pathao
        performGlobalAction(GLOBAL_ACTION_HOME)
        Prefs.addBlocked(this)

        // 3) calm screen dekhao
        handler.postDelayed({
            startActivity(
                Intent(this, CalmActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }, 350)
    }

    override fun onInterrupt() {}
}
