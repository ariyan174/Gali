package com.shanto.guard

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("shanto", Context.MODE_PRIVATE)

    fun isOn(c: Context) = sp(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()

    fun endAt(c: Context) = sp(c).getLong("end", 0L)
    fun setEnd(c: Context, t: Long) = sp(c).edit().putLong("end", t).apply()

    /** Guard on + lock time still running */
    fun isLocked(c: Context) = isOn(c) && endAt(c) > System.currentTimeMillis()

    fun custom(c: Context): Set<String> = HashSet(sp(c).getStringSet("custom", emptySet()) ?: emptySet())
    fun addWord(c: Context, w: String) =
        sp(c).edit().putStringSet("custom", custom(c) + w).apply()
    fun removeWord(c: Context, w: String) =
        sp(c).edit().putStringSet("custom", custom(c) - w).apply()

    private fun dayNow() = System.currentTimeMillis() / 86_400_000L
    fun blockedToday(c: Context): Int =
        if (sp(c).getLong("day", -1L) == dayNow()) sp(c).getInt("count", 0) else 0
    fun addBlocked(c: Context) {
        val n = blockedToday(c) + 1
        sp(c).edit().putLong("day", dayNow()).putInt("count", n).apply()
    }
}
