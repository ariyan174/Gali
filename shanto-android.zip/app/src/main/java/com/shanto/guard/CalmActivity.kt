package com.shanto.guard

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CalmActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private var step = 0
    private val steps = listOf("Shash nao" to 4000L, "Dhore rakho" to 4000L, "Dhire charo" to 6000L)
    private val tips = listOf(
        "Ragh ekta dheu. Ashe, jai. Tumi dheu na.",
        "Ekhon reply dile pore pochtate hobe. 10 minute opekkha koro.",
        "Tomar shorir ekhon alarm bajachhe. Dhire shash nao, alarm thambe.",
        "Gali muche felechho — eta tomar shokti, durbolota na.",
        "Je manush-er jonno tumi ragchho, tar jonno nijer shanti noshto koro na."
    )

    private lateinit var orb: View
    private lateinit var phase: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calm)
        orb = findViewById(R.id.orb)
        phase = findViewById(R.id.phase)
        findViewById<TextView>(R.id.tip).text = tips.random()
        findViewById<View>(R.id.btnOk).setOnClickListener { finish() }
        orb.scaleX = 0.6f
        orb.scaleY = 0.6f
        cycle()
    }

    private fun cycle() {
        val (label, ms) = steps[step % 3]
        phase.text = label
        val target = if (step % 3 == 2) 0.6f else 1.15f
        orb.animate().scaleX(target).scaleY(target).setDuration(ms).start()
        handler.postDelayed({ step++; cycle() }, ms)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
