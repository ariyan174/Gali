package com.shanto.guard

import android.content.Context

object Words {
    // Ekhane iccha moto aro word jog korte paro (ba app-er "Nijer word" theke)
    private val base = setOf(
        "fuck", "shit", "bitch", "bastard", "asshole", "mc", "bc",
        "madarchod", "bhenchod", "chutiya", "shala", "haramjada", "harami",
        "khanki", "magi", "kutta", "boka", "gandu",
        "হারামি", "হারামজাদা", "খানকি", "মাগি", "কুত্তা", "শালা", "গান্ডু"
    )

    fun hit(c: Context, text: String): Boolean {
        val t = text.lowercase()
        val all = base + Prefs.custom(c)
        val tokens = t.split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }
        return all.any { w -> w in tokens || (w.length >= 5 && t.contains(w)) }
    }
}
