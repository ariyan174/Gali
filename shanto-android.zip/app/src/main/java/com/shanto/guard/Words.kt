package com.shanto.guard

import android.content.Context

/**
 * Gali detect korar engine.
 * - Je kono chinho (@ # % & * - ' : ; / ৳ ...) gali-r age/majhe/pore thakleo detect hoy
 * - Leet: @=a, 0=o, 1=i, 3=e, 4=a, 5=s, 7=t, !=i, $=s
 * - Banglish spelling variant: kh/k, sh/s, z/j, v/b, y/i, repeated letter (fuuuck, jaroz/zaroj)
 * - Space diye bhanga (f u c k, kh an ki) ar phrase (tor mare cd)
 * Notun word jog korte shudhu nicher list-e likhe dao.
 */
object Words {
    // English / chinho-shoho word: spelling hubohu dhore
    private val english = listOf(
        "fuck", "fuk", "fck", "shit", "bitch", "bastard", "asshole", "motherfucker",
        "dick", "pussy", "cunt", "slut", "whore", "mc", "bc"
    )

    // Banglish: spelling variant onujayi dhora hoy (kh=k, sh=s, z=j, v=b ...)
    private val banglish = listOf(
        // khanki / magi / besya
        "khanki", "kanki", "khankir", "khankirpola", "khankirpo", "khankirchele",
        "magi", "maagi", "magir", "magirpola", "magirchele", "parar magi", "noti magi",
        "besya", "besha", "bessa", "beshya", "beshyar", "besar", "beshar pola", "bessar pola", "bessar chele",
        // ponda / chod / chud
        "ponda", "pondamu", "pondabo", "pondar",
        "chodna", "chodbo", "chodmu", "chudbo", "chudmu", "chudi", "chudir", "chudna", "chudani",
        "chodon", "chodar", "chudamu", "cdna", "cdbo", "cdmu",
        "bokachoda", "bokachuda", "bkcd", "bkcda",
        "chudmarani", "chutmarni", "chudmarni", "chutmarani",
        "madarchod", "madarchud", "modarchod", "madarchut", "matherchod",
        "bhenchod", "behenchod", "benchod", "bainchod", "bencho",
        "chutiya", "chutia",
        "tor mare cd", "tor mare chod", "tor mare chud", "tor mar chod", "tor mayre chod",
        // jaroj / harami / kutta
        "jaroj", "jarojer", "jarojbaccha", "harami", "haramir", "haramjada", "haramzada",
        "haramjadi", "haramkhor", "kutta", "kuttar", "kuttarbaccha", "kuttarbacha",
        "shuorer", "shuorerbaccha", "shuorerbacha",
        // gandu / gu / lund
        "gandu", "gaandu", "gand", "gandmarani", "gandmara", "gukhor", "hagu",
        "lund", "lauda", "laura", "lura", "loda", "luro", "bhoda", "voda",
        "shala", "sala", "shaala", "shalar",
        // phrase
        "basike jonmo", "abasike jonmo"
    )

    // Bangla akkhor
    private val bangla = listOf(
        "খানকি", "খানকির", "মাগি", "মাগির", "খানকির পোলা", "মাগির পোলা", "নটি মাগি",
        "বেশ্যা", "পোন্দামু", "পোন্দা", "চুদি", "চুদমু", "চুদবো", "চোদনা", "চুদানি", "চুদমারানি",
        "জারজ", "হারামি", "হারামজাদা", "কুত্তা", "কুত্তার বাচ্চা", "শুয়োরের বাচ্চা",
        "গান্ডু", "মাদারচোদ", "মাদারচুদ", "বোকাচোদা", "বোকাচুদা", "শালা", "গুখোর", "হাগু"
    )

    // ---------------------------------------------------------------- helpers
    private val leet = mapOf(
        '@' to 'a', '$' to 's', '0' to 'o', '1' to 'i', '3' to 'e',
        '4' to 'a', '5' to 's', '7' to 't', '!' to 'i', '+' to 't'
    )
    private val leetDigits = setOf('0', '1', '3', '4', '5', '7')
    private val digraphs = listOf(
        "kh" to "k", "gh" to "g", "bh" to "b", "dh" to "d",
        "th" to "t", "ph" to "f", "sh" to "s", "ch" to "c"
    )
    private const val WILD = '\u0000'

    private fun keep(ch: Char) = ch.isLetterOrDigit() ||
            ch.category == CharCategory.NON_SPACING_MARK ||
            ch.category == CharCategory.COMBINING_SPACING_MARK

    private fun isBn(s: String) = s.any { it in '\u0980'..'\u09FF' }

    /** mode 1: leet chinho (@ ! $ +) akkhor hoy, baki chinho bad. mode 2: shob chinho bad. */
    private fun view(t: String, mode: Int): String {
        val sb = StringBuilder()
        for (ch in t) {
            if (ch.isWhitespace()) {
                sb.append(' ')
            } else if (ch in leetDigits) {
                sb.append(leet[ch]!!)
            } else if (keep(ch)) {
                sb.append(ch)
            } else if (mode == 1) {
                val m = leet[ch]
                if (m != null) sb.append(m)
            }
        }
        return sb.toString()
    }

    // fuuuck -> fuck (shudhu a-z)
    private fun collapse(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            if (sb.isNotEmpty() && ch == sb.last() && ch in 'a'..'z') continue
            sb.append(ch)
        }
        return sb.toString()
    }

    // khanki -> kanki, zaroz -> jaroj
    private fun phon(s: String): String {
        var t = s
        for ((a, b) in digraphs) t = t.replace(a, b)
        val sb = StringBuilder()
        for (ch in t) {
            val m = when (ch) { 'z' -> 'j'; 'v' -> 'b'; 'q' -> 'k'; 'y' -> 'i'; else -> ch }
            if (sb.isNotEmpty() && m == sb.last() && m in 'a'..'z') continue
            sb.append(m)
        }
        return sb.toString()
    }

    private class E(val light: String, val n: String, val ph: Boolean)

    private fun mk(raw: String, ph: Boolean): E {
        val t = view(raw.lowercase(), 2).replace(" ", "")
        return E(collapse(t), if (ph) phon(t) else collapse(t), ph)
    }

    private val baseE: List<E> by lazy {
        english.map { mk(it, false) } + banglish.map { mk(it, true) } + bangla.map { mk(it, false) }
    }

    // "f u c k" -> "fuck"
    private fun toks(v: String): List<String> {
        val raw = v.split(" ").filter { it.isNotEmpty() }
        val out = mutableListOf<String>()
        var run = StringBuilder()
        for (r in raw) {
            if (r.length == 1) run.append(r)
            else {
                if (run.isNotEmpty()) { out.add(run.toString()); run = StringBuilder() }
                out.add(r)
            }
        }
        if (run.isNotEmpty()) out.add(run.toString())
        return out
    }

    private fun withinOne(a: String, b: String): Boolean {
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        var i = 0
        var j = 0
        var diff = 0
        while (i < a.length && j < b.length) {
            if (a[i] == b[j]) { i++; j++; continue }
            if (++diff > 1) return false
            when {
                a.length > b.length -> i++
                a.length < b.length -> j++
                else -> { i++; j++ }
            }
        }
        return diff + (a.length - i) + (b.length - j) <= 1
    }

    private fun scan(v: String, es: List<E>): Boolean {
        val compact = v.replace(" ", "")
        val cl = collapse(compact)
        val cp = phon(compact)
        // 1) puro text (space/chinho bad diye) -- phrase ar vanga word
        for (e in es) {
            val minC = if (isBn(e.n)) 4 else 6
            if (e.n.length >= minC && (if (e.ph) cp else cl).contains(e.n)) return true
        }
        // 2) ekta ekta word
        for (tok in toks(v)) {
            val tl = collapse(tok)
            val tp = phon(tok)
            for (e in es) {
                val x = if (e.ph) tp else tl
                if (x == e.n) return true
                if (e.ph && e.n.length >= 7 && x.length >= 6 && withinOne(x, e.n)) return true
            }
        }
        return false
    }

    // m*gi, kh#nki, mad-rchod -> chinho = je kono ekta akkhor
    private fun wildHit(t: String, es: List<E>): Boolean {
        for (r in t.split(Regex("\\s+")).filter { it.isNotEmpty() }) {
            val sb = StringBuilder()
            var sym = false
            for (ch in r) {
                if (ch in leetDigits) sb.append(leet[ch]!!)
                else if (keep(ch)) sb.append(ch)
                else { sb.append(WILD); sym = true }
            }
            if (!sym) continue
            val tok = collapse(sb.toString())
            for (e in es) {
                val w = e.light
                val n = w.length
                if (n < 4 || tok.length < n) continue
                for (i in 0..tok.length - n) {
                    var wc = 0
                    var ok = true
                    for (j in 0 until n) {
                        val a = tok[i + j]
                        if (a == WILD) wc++ else if (a != w[j]) { ok = false; break }
                    }
                    if (ok && wc >= 1 && wc * 2 <= n) return true
                }
            }
        }
        return false
    }

    fun hit(c: Context, text: String): Boolean {
        val t = text.lowercase()
        val es = baseE + Prefs.custom(c).map { mk(it, false) }
        val plain = t.split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).joinToString(" ")
        for (v in listOf(plain, view(t, 1), view(t, 2))) {
            if (scan(v, es)) return true
        }
        return wildHit(t, es)
    }
}
